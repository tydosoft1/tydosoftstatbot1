/*
 * Проверка логики раздела «Инвайты»: даты, статусы, продление, участники, импорт, уведомления.
 *
 * Запуск из корня репозитория (нужен Node 18 или новее, ставить ничего не надо):
 *
 *   node --test tests/invites-core.test.js
 *
 * Чтобы убедиться, что часовой пояс ни на что не влияет (Linux и macOS):
 *
 *   TZ=Europe/Minsk node --test tests/invites-core.test.js
 *   TZ=America/Los_Angeles node --test tests/invites-core.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');

const Core = require(path.join(__dirname, '..', 'fp статистика', 'invites-core.js'));

const NOW = 1790000000000; // условная метка «когда записали»

/** Состояние с готовыми аккаунтами: [email, дата покупки, дата окончания (необязательно)]. */
function stateWith(rows) {
  const state = Core.emptyState();
  rows.forEach((row, index) => {
    Core.createAccount(
      state,
      { email: row[0], password: 'pw-' + index, subscriptionStartDate: row[1], subscriptionEndDate: row[2] || '' },
      NOW + index
    );
  });
  return state;
}

function addMembers(state, account, count, endDate) {
  for (let i = 0; i < count; i += 1) {
    Core.addMember(state, account.id, { nickname: '@user' + account.members.length, endDate: endDate || '2027-01-01' }, NOW);
  }
}

const codeOf = (fn) => {
  try {
    fn();
  } catch (error) {
    return error.code;
  }
  return null;
};

/* ───────────────────────── Даты ───────────────────────── */

test('дата разбирается только если это настоящий день календаря', () => {
  assert.deepEqual(Core.parseDate('2026-10-06'), { y: 2026, m: 10, d: 6 });
  assert.equal(Core.isDate('2028-02-29'), true, '2028 — високосный');
  assert.equal(Core.isDate('2027-02-29'), false);
  assert.equal(Core.isDate('2100-02-29'), false, '2100 — не високосный');
  assert.equal(Core.isDate('2026-02-30'), false);
  assert.equal(Core.isDate('2026-13-01'), false);
  assert.equal(Core.isDate('2026-00-10'), false);
  assert.equal(Core.isDate('2026-04-31'), false);
  assert.equal(Core.isDate('2026-1-5'), false);
  assert.equal(Core.isDate('06.10.2026'), false);
  assert.equal(Core.isDate('0202-10-06'), false, 'год, набранный не до конца');
  assert.equal(Core.isDate(''), false);
  assert.equal(Core.isDate(null), false);
  assert.equal(Core.isDate(20261006), false);
});

test('дата показывается как ДД.ММ.ГГГГ', () => {
  assert.equal(Core.formatDate('2026-10-06'), '06.10.2026');
  assert.equal(Core.formatDate('2026-01-31'), '31.01.2026');
  assert.equal(Core.formatDate('чепуха'), '—');
});

test('дата, набранная руками: день, месяц, год в любом привычном виде', () => {
  assert.equal(Core.readDate('06.10.2026'), '2026-10-06');
  assert.equal(Core.readDate('6.10.2026'), '2026-10-06');
  assert.equal(Core.readDate('6.1.2027'), '2027-01-06');
  assert.equal(Core.readDate('06.10.26'), '2026-10-06', 'год двумя цифрами');
  assert.equal(Core.readDate('06/10/2026'), '2026-10-06', 'косая черта — тоже день и месяц, не наоборот');
  assert.equal(Core.readDate('06-10-2026'), '2026-10-06');
  assert.equal(Core.readDate('06,10,2026'), '2026-10-06', 'запятая с цифровой клавиатуры');
  assert.equal(Core.readDate('06 10 2026'), '2026-10-06');
  assert.equal(Core.readDate('06102026'), '2026-10-06', 'одни цифры');
  assert.equal(Core.readDate('061026'), '2026-10-06');
  assert.equal(Core.readDate('  31.01.2027  '), '2027-01-31');
  assert.equal(Core.readDate('2026-10-06'), '2026-10-06', 'вставили дату из файла');
  assert.equal(Core.readDate('29.02.2028'), '2028-02-29');

  assert.equal(Core.readDate(''), '', 'пусто — это «не заполнено», а не ошибка');
  assert.equal(Core.readDate('   '), '');
  assert.equal(Core.readDate(null), '');
  assert.equal(Core.readDate(undefined), '');

  for (const wrong of ['31.02.2026', '29.02.2027', '32.01.2026', '00.10.2026', '06.13.2026', '06.10', '06.10.', '6102026', '06.10.202', '06.10.20266', 'завтра', '06.10.1999', '06.10.2101', '2026-13-01', '10/06/2026/1', '06..10..2026x']) {
    assert.equal(Core.readDate(wrong), null, wrong);
  }
  assert.equal(Core.readDate(Core.formatDate('2026-12-31')), '2026-12-31', 'показанную дату можно прочитать обратно');
});

test('сегодня — это местный день, а не день по UTC', () => {
  const justAfterMidnight = new Date(2026, 9, 6, 0, 5);
  const justBeforeMidnight = new Date(2026, 9, 5, 23, 55);
  assert.equal(Core.today(justAfterMidnight), '2026-10-06');
  assert.equal(Core.today(justBeforeMidnight), '2026-10-05');

  // Там, где местное время впереди UTC (Минск, Москва), в 00:05 по UTC ещё вчера —
  // именно эта разница и не должна попадать в расчёты.
  if (justAfterMidnight.getTimezoneOffset() < 0) {
    assert.equal(justAfterMidnight.toISOString().slice(0, 10), '2026-10-05');
  }
  if (justBeforeMidnight.getTimezoneOffset() > 0) {
    assert.equal(justBeforeMidnight.toISOString().slice(0, 10), '2026-10-06');
  }
  assert.match(Core.today(), /^\d{4}-\d{2}-\d{2}$/);
});

test('разница в днях не зависит от перевода часов и границ года', () => {
  assert.equal(Core.diffDays('2026-11-06', '2026-10-06'), 31);
  assert.equal(Core.diffDays('2026-10-06', '2026-10-06'), 0);
  assert.equal(Core.diffDays('2026-10-05', '2026-10-06'), -1);
  assert.equal(Core.diffDays('2026-03-30', '2026-03-28'), 2, 'весенний перевод часов в Европе');
  assert.equal(Core.diffDays('2026-10-26', '2026-10-24'), 2, 'осенний перевод часов в Европе');
  assert.equal(Core.diffDays('2026-03-09', '2026-03-07'), 2, 'весенний перевод часов в США');
  assert.equal(Core.diffDays('2027-01-01', '2026-12-31'), 1);
  assert.equal(Core.diffDays('2028-03-01', '2028-02-28'), 2, 'високосный февраль');
  assert.ok(Number.isNaN(Core.diffDays('чепуха', '2026-10-06')));
});

test('addDays ходит через границы месяца и года', () => {
  assert.equal(Core.addDays('2026-10-31', 1), '2026-11-01');
  assert.equal(Core.addDays('2026-12-31', 1), '2027-01-01');
  assert.equal(Core.addDays('2026-03-01', -1), '2026-02-28');
  assert.equal(Core.addDays('2028-03-01', -1), '2028-02-29');
  assert.equal(Core.addDays('чепуха', 1), null);
});

test('плюс месяц — календарный месяц, а не 30 дней', () => {
  assert.equal(Core.addMonths('2026-10-06', 1), '2026-11-06', 'пример из ТЗ');
  assert.equal(Core.addMonths('2026-09-06', 1), '2026-10-06');
  assert.equal(Core.addMonths('2026-10-20', 1), '2026-11-20');
  assert.equal(Core.addMonths('2026-12-15', 1), '2027-01-15', 'переход через год');
  assert.equal(Core.addMonths('2026-02-10', 1), '2026-03-10', 'после февраля не теряются дни');
  assert.equal(Core.addMonths('2026-07-31', 1), '2026-08-31', 'два длинных месяца подряд');
});

test('31 января + 1 месяц = последний день февраля', () => {
  assert.equal(Core.addMonths('2027-01-31', 1), '2027-02-28');
  assert.equal(Core.addMonths('2028-01-31', 1), '2028-02-29', 'високосный год');
  assert.equal(Core.addMonths('2027-01-30', 1), '2027-02-28');
  assert.equal(Core.addMonths('2027-01-29', 1), '2027-02-28');
  assert.equal(Core.addMonths('2027-01-28', 1), '2027-02-28');
  assert.equal(Core.addMonths('2026-03-31', 1), '2026-04-30');
  assert.equal(Core.addMonths('2026-05-31', 1), '2026-06-30');
  assert.equal(Core.addMonths('2026-12-31', 1), '2027-01-31');
  assert.equal(Core.addMonths('2026-12-31', 2), '2027-02-28');
  for (let month = 1; month <= 12; month += 1) {
    const from = '2027-' + String(month).padStart(2, '0') + '-31';
    if (!Core.isDate(from)) continue;
    assert.ok(Core.isDate(Core.addMonths(from, 1)), from + ' + 1 месяц должен быть настоящим днём');
  }
});

test('число оплаты возвращает срок на место после короткого месяца', () => {
  assert.equal(Core.addMonths('2027-02-28', 1, 31), '2027-03-31');
  assert.equal(Core.addMonths('2027-03-31', 1, 31), '2027-04-30');
  assert.equal(Core.addMonths('2027-04-30', 1, 31), '2027-05-31');
  assert.equal(Core.addMonths('2027-02-28', 1, 30), '2027-03-30');
  assert.equal(Core.addMonths('2028-02-29', 1, 31), '2028-03-31');
  // Число оплаты не должно сдвигать дату, которая не была урезана.
  assert.equal(Core.addMonths('2026-10-20', 1, 31), '2026-11-20');
  assert.equal(Core.addMonths('2028-02-28', 1, 31), '2028-03-28', '28.02 в високосном году — не конец месяца');
  assert.equal(Core.addMonths('2026-10-20', 1, 15), '2026-11-20', 'число меньше текущего ни на что не влияет');
  assert.equal(Core.addMonths('2026-04-30', 1, 30), '2026-05-30');
});

test('месяцы можно и вычитать', () => {
  assert.equal(Core.addMonths('2026-11-06', -1), '2026-10-06');
  assert.equal(Core.addMonths('2027-01-15', -1), '2026-12-15');
  assert.equal(Core.addMonths('2026-03-31', -1), '2026-02-28');
  assert.equal(Core.addMonths('чепуха', 1), null);
});

/* ───────────────────────── Статусы ───────────────────────── */

test('статус считается от сегодняшнего дня', () => {
  const today = '2026-10-06';
  assert.equal(Core.statusOf('2026-11-06', today, 7), 'active');
  assert.equal(Core.statusOf('2026-10-14', today, 7), 'active', 'осталось 8 дней');
  assert.equal(Core.statusOf('2026-10-13', today, 7), 'soon', 'осталось ровно 7 дней');
  assert.equal(Core.statusOf('2026-10-07', today, 7), 'soon', 'завтра');
  assert.equal(Core.statusOf('2026-10-06', today, 7), 'soon', 'день окончания — ещё не истёк');
  assert.equal(Core.statusOf('2026-10-05', today, 7), 'expired', 'на следующий день после окончания');
  assert.equal(Core.statusOf('2026-09-20', today, 7), 'expired');
});

test('порог «Скоро истекает» настраивается', () => {
  const today = '2026-10-06';
  assert.equal(Core.statusOf('2026-10-13', today, 3), 'active');
  assert.equal(Core.statusOf('2026-10-09', today, 3), 'soon');
  assert.equal(Core.statusOf('2026-10-20', today, 14), 'soon');
  assert.equal(Core.statusOf('2026-10-07', today, 0), 'active');
  assert.equal(Core.statusOf('2026-10-06', today, 0), 'soon', 'при пороге 0 предупреждает только последний день');
});

test('статус меняется сам, когда меняется день', () => {
  const state = stateWith([['a@example.com', '2026-10-06']]);
  const account = state.accounts[0];
  const statusOn = (day) => Core.describeAccount(account, day, 7).status;
  assert.equal(statusOn('2026-10-06'), 'active');
  assert.equal(statusOn('2026-10-29'), 'active');
  assert.equal(statusOn('2026-10-30'), 'soon');
  assert.equal(statusOn('2026-11-06'), 'soon');
  assert.equal(statusOn('2026-11-07'), 'expired');
  assert.equal(Core.describeAccount(account, '2026-11-07', 7).daysLeft, -1);
  assert.equal(account.archived, false, 'истёкший аккаунт никуда не девается и в архив сам не уходит');
});

/* ───────────────────────── Аккаунты ───────────────────────── */

test('новый аккаунт: окончание = покупка + 1 календарный месяц', () => {
  const state = Core.emptyState();
  const account = Core.createAccount(
    state,
    { email: '  example@gmail.com ', password: ' pass word ', subscriptionStartDate: '2026-10-06' },
    NOW
  );
  assert.equal(account.email, 'example@gmail.com', 'пробелы вокруг email убираются');
  assert.equal(account.password, ' pass word ', 'пароль хранится как введён');
  assert.equal(account.subscriptionStartDate, '2026-10-06');
  assert.equal(account.subscriptionEndDate, '2026-11-06');
  assert.equal(account.archived, false);
  assert.deepEqual(account.members, []);
  assert.equal(account.renewalHistory.length, 1);
  assert.equal(account.renewalHistory[0].type, 'purchase');
  assert.equal(account.renewalHistory[0].date, '2026-10-06');
  assert.equal(account.renewalHistory[0].endDate, '2026-11-06');
  assert.equal(state.accounts.length, 1);
});

test('дату окончания можно задать вручную', () => {
  const state = Core.emptyState();
  const account = Core.createAccount(
    state,
    { email: 'a@example.com', password: 'p', subscriptionStartDate: '2026-10-06', subscriptionEndDate: '2026-11-10' },
    NOW
  );
  assert.equal(account.subscriptionEndDate, '2026-11-10');
  assert.equal(account.anchorDay, 10, 'дальше срок держится за число, заданное руками');
  assert.equal(Core.renewAccount(state, account.id, { date: '2026-10-07' }, NOW).endDate, '2026-12-10');
});

test('форма аккаунта: чего не хватает и что не так', () => {
  const check = (input) => Core.checkAccount(input).errors;
  assert.deepEqual(check({}), { email: 'missing', password: 'missing', start: 'missing' });
  assert.deepEqual(check({ email: 'не почта', password: 'p', subscriptionStartDate: '2026-10-06' }), { email: 'invalid' });
  assert.deepEqual(check({ email: 'a b@example.com', password: 'p', subscriptionStartDate: '2026-10-06' }), { email: 'invalid' });
  assert.deepEqual(check({ email: 'a@example.com', password: '', subscriptionStartDate: '2026-10-06' }), { password: 'missing' });
  assert.deepEqual(check({ email: 'a@example.com', password: 'p', subscriptionStartDate: '2026-02-30' }), { start: 'invalid' });
  assert.deepEqual(
    check({ email: 'a@example.com', password: 'p', subscriptionStartDate: '2026-10-06', subscriptionEndDate: '2026-10-01' }),
    { end: 'before-start' }
  );
  assert.deepEqual(
    check({ email: 'a@example.com', password: 'p', subscriptionStartDate: '2026-10-06', subscriptionEndDate: '2026-13-01' }),
    { end: 'invalid' }
  );
  assert.equal(codeOf(() => Core.createAccount(Core.emptyState(), { email: 'x' }, NOW)), 'invalid-input');
});

test('у каждого аккаунта свой идентификатор', () => {
  const state = stateWith(
    Array.from({ length: 60 }, (unused, index) => ['user' + index + '@example.com', '2026-10-06'])
  );
  assert.equal(new Set(state.accounts.map((account) => account.id)).size, 60);
});

test('правка аккаунта: данные меняются, изменение дат попадает в историю', () => {
  const state = stateWith([['a@example.com', '2026-10-06']]);
  const id = state.accounts[0].id;

  Core.updateAccount(
    state,
    id,
    { label: 'Spotify Family', email: 'b@example.com', password: 'new', subscriptionStartDate: '2026-10-06', subscriptionEndDate: '2026-11-06' },
    '2026-10-07',
    NOW
  );
  let account = state.accounts[0];
  assert.equal(account.label, 'Spotify Family');
  assert.equal(account.email, 'b@example.com');
  assert.equal(account.password, 'new');
  assert.equal(account.renewalHistory.length, 1, 'даты не трогали — в истории ничего нового');

  Core.updateAccount(
    state,
    id,
    { email: 'b@example.com', password: 'new', subscriptionStartDate: '2026-10-06', subscriptionEndDate: '2026-11-15' },
    '2026-10-07',
    NOW
  );
  account = state.accounts[0];
  assert.equal(account.subscriptionEndDate, '2026-11-15');
  assert.equal(account.renewalHistory.length, 2);
  assert.deepEqual(
    { type: account.renewalHistory[1].type, date: account.renewalHistory[1].date, from: account.renewalHistory[1].previousEndDate, to: account.renewalHistory[1].endDate },
    { type: 'edit', date: '2026-10-07', from: '2026-11-06', to: '2026-11-15' }
  );
  assert.equal(codeOf(() => Core.updateAccount(state, 'нет такого', {}, '2026-10-07', NOW)), 'account-missing');
});

test('правка названия не сбивает число оплаты у продлённого аккаунта', () => {
  const state = stateWith([['a@example.com', '2027-01-31']]);
  const account = state.accounts[0];
  Core.renewAccount(state, account.id, { date: '2027-02-10' }, NOW);
  assert.equal(account.subscriptionEndDate, '2027-03-31');
  Core.updateAccount(
    state,
    account.id,
    { label: 'Семья', email: 'a@example.com', password: 'p', subscriptionStartDate: '2027-01-31', subscriptionEndDate: '2027-03-31' },
    '2027-02-11',
    NOW
  );
  Core.renewAccount(state, account.id, { date: '2027-02-12' }, NOW);
  assert.equal(account.subscriptionEndDate, '2027-04-30');
  Core.renewAccount(state, account.id, { date: '2027-02-13' }, NOW);
  assert.equal(account.subscriptionEndDate, '2027-05-31');
});

test('удаление аккаунта и возврат на прежнее место', () => {
  const state = stateWith([['a@example.com', '2026-10-06'], ['b@example.com', '2026-10-06'], ['c@example.com', '2026-10-06']]);
  const removed = Core.deleteAccount(state, state.accounts[1].id);
  assert.deepEqual(state.accounts.map((a) => a.email), ['a@example.com', 'c@example.com']);
  assert.equal(removed.account.email, 'b@example.com');
  Core.restoreAccount(state, removed);
  assert.deepEqual(state.accounts.map((a) => a.email), ['a@example.com', 'b@example.com', 'c@example.com']);
  Core.restoreAccount(state, removed);
  assert.equal(state.accounts.length, 3, 'повторный возврат не создаёт двойника');
  assert.equal(codeOf(() => Core.deleteAccount(state, 'нет такого')), 'account-missing');
});

/* ───────────────────────── Участники ───────────────────────── */

test('в аккаунте не больше пяти участников', () => {
  const state = stateWith([['a@example.com', '2026-10-06']]);
  const account = state.accounts[0];
  for (let i = 1; i <= 5; i += 1) {
    Core.addMember(state, account.id, { nickname: '@user' + i, endDate: '2026-11-0' + i }, NOW);
    assert.equal(account.members.length, i);
  }
  assert.equal(codeOf(() => Core.addMember(state, account.id, { nickname: '@sixth', endDate: '2026-11-06' }, NOW)), 'members-full');
  assert.equal(account.members.length, 5);
  assert.equal(new Set(account.members.map((member) => member.id)).size, 5, 'идентификаторы участников не повторяются');
  const view = Core.describeAccount(account, '2026-10-06', 7);
  assert.equal(view.used, 5);
  assert.equal(view.free, 0);
});

test('форма участника: ник и дата «оплачено до» обязательны', () => {
  const check = (input) => Core.checkMember(input).errors;
  assert.deepEqual(check({}), { nickname: 'missing', end: 'missing' });
  assert.deepEqual(check({ nickname: '   ', endDate: '2026-11-06' }), { nickname: 'missing' });
  assert.deepEqual(check({ nickname: '@alex', endDate: '2026-02-30' }), { end: 'invalid' });
  assert.deepEqual(check({ nickname: '@alex', endDate: '2026-11-06', startDate: '2026-12-01' }), { end: 'before-start' });
  assert.deepEqual(check({ nickname: '@alex', endDate: '2026-11-06', startDate: 'чепуха' }), { start: 'invalid' });
  assert.deepEqual(check({ nickname: '@alex', endDate: '2026-11-06' }), {});
  assert.deepEqual(check({ nickname: '@alex', endDate: '2026-11-06', startDate: '2026-10-06' }), {});
  const state = stateWith([['a@example.com', '2026-10-06']]);
  assert.equal(codeOf(() => Core.addMember(state, state.accounts[0].id, { nickname: '' }, NOW)), 'invalid-input');
});

test('правка одного участника не трогает остальных', () => {
  const state = stateWith([['a@example.com', '2026-10-06']]);
  const account = state.accounts[0];
  Core.addMember(state, account.id, { nickname: '@alex', endDate: '2026-10-20' }, NOW);
  Core.addMember(state, account.id, { nickname: '@max', endDate: '2026-11-01' }, NOW);
  Core.addMember(state, account.id, { nickname: '@john', endDate: '2026-11-06' }, NOW);
  const before = JSON.stringify([account.members[0], account.members[2]]);

  Core.updateMember(state, account.id, account.members[1].id, { nickname: '@maxim', endDate: '2026-12-01', startDate: '2026-10-01' });
  assert.equal(account.members[1].nickname, '@maxim');
  assert.equal(account.members[1].endDate, '2026-12-01');
  assert.equal(account.members[1].startDate, '2026-10-01');
  assert.equal(JSON.stringify([account.members[0], account.members[2]]), before);
  assert.equal(codeOf(() => Core.updateMember(state, account.id, 'нет такого', { nickname: 'x', endDate: '2026-12-01' })), 'member-missing');
});

test('срок участника не зависит от срока аккаунта', () => {
  const state = stateWith([['a@example.com', '2026-10-06']]); // аккаунт до 06.11.2026
  const account = state.accounts[0];
  Core.addMember(state, account.id, { nickname: '@alex', endDate: '2026-10-20' }, NOW);
  Core.addMember(state, account.id, { nickname: '@max', endDate: '2026-11-01' }, NOW);
  Core.addMember(state, account.id, { nickname: '@john', endDate: '2026-11-06' }, NOW);
  Core.addMember(state, account.id, { nickname: '@kate', endDate: '2026-12-25' }, NOW);

  const view = Core.describeAccount(account, '2026-10-25', 7);
  assert.equal(view.status, 'active');
  assert.deepEqual(view.members.map((item) => item.status), ['expired', 'soon', 'active', 'active']);
  assert.deepEqual(view.members.map((item) => item.daysLeft), [-5, 7, 12, 61]);
  assert.equal(account.archived, false, 'из-за истёкшего участника аккаунт в архив не уходит');
  assert.equal(account.subscriptionEndDate, '2026-11-06');
});

test('удаление участника и возврат; на занятое место не возвращается', () => {
  const state = stateWith([['a@example.com', '2026-10-06']]);
  const account = state.accounts[0];
  addMembers(state, account, 5);
  const removed = Core.removeMember(state, account.id, account.members[1].id);
  assert.equal(account.members.length, 4);
  Core.restoreMember(state, account.id, removed);
  assert.equal(account.members.length, 5);
  assert.equal(account.members[1].id, removed.member.id, 'участник вернулся на своё место');

  const again = Core.removeMember(state, account.id, account.members[0].id);
  Core.addMember(state, account.id, { nickname: '@new', endDate: '2027-01-01' }, NOW);
  assert.equal(codeOf(() => Core.restoreMember(state, account.id, again)), 'members-full');
  assert.equal(account.members.length, 5);
});

/* ───────────────────────── Продление ───────────────────────── */

test('продление действующей подписки прибавляет месяц к дате окончания', () => {
  const state = stateWith([['a@example.com', '2026-09-20']]); // до 20.10.2026
  const account = state.accounts[0];
  const result = Core.renewAccount(state, account.id, { date: '2026-10-10', expectedEndDate: '2026-10-20' }, NOW);
  assert.equal(result.extended, true);
  assert.equal(account.subscriptionEndDate, '2026-11-20', 'не 09.11 и не 10.11');
  assert.equal(account.subscriptionStartDate, '2026-09-20', 'подписка не прерывалась — дата покупки прежняя');
  const entry = account.renewalHistory[1];
  assert.deepEqual(
    { type: entry.type, date: entry.date, from: entry.previousEndDate, to: entry.endDate },
    { type: 'renew', date: '2026-10-10', from: '2026-10-20', to: '2026-11-20' }
  );
});

test('продление в последний день считается от даты окончания', () => {
  const state = stateWith([['a@example.com', '2026-09-06']]); // до 06.10.2026
  const account = state.accounts[0];
  const result = Core.renewAccount(state, account.id, { date: '2026-10-06' }, NOW);
  assert.equal(result.extended, true);
  assert.equal(account.subscriptionEndDate, '2026-11-06');
});

test('продление истёкшей подписки считается со дня оплаты', () => {
  const state = stateWith([['a@example.com', '2026-08-20']]); // до 20.09.2026
  const account = state.accounts[0];
  assert.equal(Core.statusOf(account.subscriptionEndDate, '2026-10-06', 7), 'expired');
  const result = Core.renewAccount(state, account.id, { date: '2026-10-06', expectedEndDate: '2026-09-20' }, NOW);
  assert.equal(result.extended, false);
  assert.equal(account.subscriptionStartDate, '2026-10-06', 'новая дата начала');
  assert.equal(account.subscriptionEndDate, '2026-11-06', 'не 20.10');
  assert.equal(Core.statusOf(account.subscriptionEndDate, '2026-10-06', 7), 'active');
  assert.equal(account.renewalHistory[1].type, 'renew');
});

test('оплатили вовремя, а записали позже — месяц всё равно прибавляется к сроку', () => {
  const state = stateWith([['a@example.com', '2026-09-03']]); // до 03.10.2026
  const account = state.accounts[0];
  Core.renewAccount(state, account.id, { date: '2026-10-03' }, NOW); // записано 06.10, оплачено 03.10
  assert.equal(account.subscriptionEndDate, '2026-11-03');
});

test('повторное нажатие «Продлил» не добавляет второй месяц', () => {
  const state = stateWith([['a@example.com', '2026-09-20']]);
  const account = state.accounts[0];
  const seen = account.subscriptionEndDate; // срок, который был на экране в момент подтверждения
  Core.renewAccount(state, account.id, { date: '2026-10-10', expectedEndDate: seen }, NOW);
  assert.equal(account.subscriptionEndDate, '2026-11-20');
  assert.equal(codeOf(() => Core.renewAccount(state, account.id, { date: '2026-10-10', expectedEndDate: seen }, NOW)), 'stale');
  assert.equal(account.subscriptionEndDate, '2026-11-20');
  assert.equal(account.renewalHistory.length, 2);
  assert.equal(codeOf(() => Core.renewAccount(state, account.id, { date: 'чепуха' }, NOW)), 'invalid-date');
});

test('купленная 31-го подписка не съезжает на 28-е', () => {
  const state = stateWith([['a@example.com', '2027-01-31']]);
  const account = state.accounts[0];
  assert.equal(account.subscriptionEndDate, '2027-02-28');
  const ends = [];
  for (let i = 0; i < 12; i += 1) {
    Core.renewAccount(state, account.id, { date: '2027-02-01' }, NOW);
    ends.push(account.subscriptionEndDate);
  }
  assert.deepEqual(ends, [
    '2027-03-31', '2027-04-30', '2027-05-31', '2027-06-30', '2027-07-31', '2027-08-31',
    '2027-09-30', '2027-10-31', '2027-11-30', '2027-12-31', '2028-01-31', '2028-02-29',
  ]);
  for (const end of ends) assert.ok(Core.isDate(end));
});

test('отмена продления возвращает прежний срок', () => {
  const state = stateWith([['a@example.com', '2026-08-20']]); // истёк 20.09.2026
  const account = state.accounts[0];
  const before = JSON.stringify(account);
  const result = Core.renewAccount(state, account.id, { date: '2026-10-06' }, NOW);
  assert.equal(Core.undoRenewals(state, [result.undo]), 1);
  assert.equal(JSON.stringify(account), before);
});

test('отменить продление нельзя, если аккаунт успели изменить', () => {
  const state = stateWith([['a@example.com', '2026-09-20']]);
  const account = state.accounts[0];
  const first = Core.renewAccount(state, account.id, { date: '2026-10-10' }, NOW);
  Core.renewAccount(state, account.id, { date: '2026-10-11' }, NOW);
  assert.equal(codeOf(() => Core.undoRenewals(state, [first.undo])), 'stale');
  assert.equal(account.subscriptionEndDate, '2026-12-20');
  assert.equal(account.renewalHistory.length, 3);
});

test('история хранит каждую операцию отдельной записью', () => {
  const state = stateWith([['a@example.com', '2026-09-06']]);
  const account = state.accounts[0];
  Core.renewAccount(state, account.id, { date: '2026-10-06' }, NOW + 1);
  Core.renewAccount(state, account.id, { date: '2026-11-06' }, NOW + 2);
  assert.deepEqual(
    account.renewalHistory.map((entry) => [entry.date, entry.type, entry.endDate]),
    [
      ['2026-09-06', 'purchase', '2026-10-06'],
      ['2026-10-06', 'renew', '2026-11-06'],
      ['2026-11-06', 'renew', '2026-12-06'],
    ]
  );
  assert.equal(new Set(account.renewalHistory.map((entry) => entry.id)).size, 3);
});

/* ───────────────────────── Истёкшие и повторная покупка ───────────────────────── */

test('повторная покупка возвращает выбранные аккаунты в действующие', () => {
  const state = stateWith([
    ['account1@gmail.com', '2026-08-20'],
    ['account2@gmail.com', '2026-07-01'],
    ['account3@gmail.com', '2026-08-25'],
  ]);
  const today = '2026-10-06';
  addMembers(state, state.accounts[0], 3);
  assert.equal(Core.summarize(state, today).expired, 3);

  const picked = state.accounts.slice(0, 2).map((account) => ({ id: account.id, expectedEndDate: account.subscriptionEndDate }));
  const results = Core.rebuyAccounts(state, picked, today, NOW);
  assert.equal(results.length, 2);

  for (const account of state.accounts.slice(0, 2)) {
    assert.equal(account.subscriptionStartDate, '2026-10-06');
    assert.equal(account.subscriptionEndDate, '2026-11-06');
    assert.equal(Core.statusOf(account.subscriptionEndDate, today, 7), 'active');
    const last = account.renewalHistory[account.renewalHistory.length - 1];
    assert.equal(last.type, 'rebuy');
    assert.equal(last.date, '2026-10-06');
    assert.equal(last.endDate, '2026-11-06');
  }
  assert.equal(state.accounts[0].members.length, 3, 'участники остаются на месте');
  assert.equal(state.accounts[2].subscriptionEndDate, '2026-09-25', 'невыбранный аккаунт не тронут');
  assert.deepEqual(
    { active: Core.summarize(state, today).active, expired: Core.summarize(state, today).expired },
    { active: 2, expired: 1 }
  );

  Core.undoRenewals(state, results.map((result) => result.undo));
  assert.equal(Core.summarize(state, today).expired, 3, 'отмена возвращает всё как было');
});

test('повторная покупка — всё или ничего', () => {
  const state = stateWith([['a@example.com', '2026-08-20'], ['b@example.com', '2026-08-25']]);
  const before = JSON.stringify(state);
  const picked = [
    { id: state.accounts[0].id, expectedEndDate: '2026-09-20' },
    { id: state.accounts[1].id, expectedEndDate: '2026-01-01' }, // срок уже другой
  ];
  assert.equal(codeOf(() => Core.rebuyAccounts(state, picked, '2026-10-06', NOW)), 'stale');
  assert.equal(JSON.stringify(state), before);
  assert.equal(codeOf(() => Core.rebuyAccounts(state, [{ id: 'нет такого' }], '2026-10-06', NOW)), 'account-missing');
  assert.equal(codeOf(() => Core.rebuyAccounts(state, picked, 'чепуха', NOW)), 'invalid-date');
  assert.equal(JSON.stringify(state), before);
});

/* ───────────────────────── Архив ───────────────────────── */

test('архив — ручная отметка: аккаунт скрыт, но не удалён, и возвращается как был', () => {
  const state = stateWith([['a@example.com', '2026-10-06'], ['b@example.com', '2026-08-20']]);
  const today = '2026-10-10';
  Core.setArchived(state, state.accounts[1].id, true);

  let sum = Core.summarize(state, today);
  assert.deepEqual({ total: sum.total, expired: sum.expired, archived: sum.archived }, { total: 1, expired: 0, archived: 1 });
  let shown = Core.selectAccounts(state, { filter: 'all' }, today);
  assert.equal(shown.count, 1);
  shown = Core.selectAccounts(state, { filter: 'archived' }, today);
  assert.deepEqual(shown.groups.archived.map((view) => view.account.email), ['b@example.com']);
  assert.equal(shown.groups.archived[0].status, 'expired', 'статус в архиве по-прежнему считается от даты');

  Core.setArchived(state, state.accounts[1].id, false);
  sum = Core.summarize(state, today);
  assert.deepEqual({ total: sum.total, expired: sum.expired, archived: sum.archived }, { total: 2, expired: 1, archived: 0 });
  assert.equal(state.accounts.length, 2);
});

/* ───────────────────────── Сводка, поиск, фильтры ───────────────────────── */

test('сводка сходится с примером из ТЗ: 25 аккаунтов, 18 активных, 7 истёкших, 74 участника, 16 мест, 4 скоро', () => {
  const today = '2026-10-06';
  const rows = [];
  for (let i = 0; i < 14; i += 1) rows.push(['active' + i + '@example.com', '2026-10-01']); // до 01.11
  for (let i = 0; i < 4; i += 1) rows.push(['soon' + i + '@example.com', '2026-09-10']); // до 10.10
  for (let i = 0; i < 7; i += 1) rows.push(['old' + i + '@example.com', '2026-08-01']); // до 01.09
  const state = stateWith(rows);
  // 18 действующих аккаунтов × 5 мест = 90: занято 74, свободно 16
  const seats = [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 4, 4, 4, 4, 2, 2, 2, 2];
  state.accounts.slice(0, 18).forEach((account, index) => addMembers(state, account, seats[index]));
  addMembers(state, state.accounts[20], 3); // участники истёкшего аккаунта в сводку мест не входят

  assert.deepEqual(Core.summarize(state, today), {
    total: 25,
    active: 18,
    soon: 4,
    expired: 7,
    members: 74,
    freeSeats: 16,
    withFree: 8,
    full: 10,
    archived: 0,
  });
});

function sampleState() {
  const state = stateWith([
    ['alpha@gmail.com', '2026-10-01'], // до 01.11 — активен
    ['bravo@gmail.com', '2026-09-10'], // до 10.10 — скоро истекает
    ['charlie@mail.ru', '2026-08-20'], // до 20.09 — истёк
    ['delta@gmail.com', '2026-09-28'], // до 28.10 — активен, заполнен
    ['echo@gmail.com', '2026-08-01'], // до 01.09 — истёк, в архиве
  ]);
  const [alpha, bravo, charlie, delta, echo] = state.accounts;
  alpha.label = 'Spotify Family';
  Core.addMember(state, alpha.id, { nickname: '@Alex', endDate: '2026-11-15' }, NOW);
  Core.addMember(state, alpha.id, { nickname: 'max', endDate: '2026-12-02' }, NOW);
  Core.addMember(state, bravo.id, { nickname: '@john', endDate: '2026-10-20' }, NOW);
  Core.addMember(state, charlie.id, { nickname: '@kate', endDate: '2026-11-05' }, NOW);
  addMembers(state, delta, 5);
  Core.addMember(state, echo.id, { nickname: '@alexa', endDate: '2026-09-01' }, NOW);
  Core.setArchived(state, echo.id, true);
  return state;
}

const emails = (views) => views.map((view) => view.account.email);

test('фильтры отбирают один и тот же список по сроку и местам', () => {
  const state = sampleState();
  const today = '2026-10-06';
  const pick = (filter) => Core.selectAccounts(state, { filter: filter }, today);

  let shown = pick('all');
  assert.deepEqual(emails(shown.groups.active), ['bravo@gmail.com', 'delta@gmail.com', 'alpha@gmail.com']);
  assert.deepEqual(emails(shown.groups.expired), ['charlie@mail.ru']);
  assert.deepEqual(shown.groups.archived, []);

  shown = pick('active');
  assert.equal(shown.groups.active.length, 3);
  assert.equal(shown.groups.expired.length, 0);

  assert.deepEqual(emails(pick('soon').groups.active), ['bravo@gmail.com']);

  shown = pick('expired');
  assert.deepEqual(emails(shown.groups.expired), ['charlie@mail.ru']);
  assert.equal(shown.groups.active.length, 0);

  assert.deepEqual(emails(pick('free').groups.active), ['bravo@gmail.com', 'alpha@gmail.com']);
  assert.equal(pick('free').groups.expired.length, 0, 'место в истёкшей подписке занять нельзя');
  assert.deepEqual(emails(pick('full').groups.active), ['delta@gmail.com']);
  assert.deepEqual(emails(pick('archived').groups.archived), ['echo@gmail.com']);
  assert.equal(pick('чепуха').count, 4, 'неизвестный фильтр — это «Все»');
});

test('поиск идёт по email, названию и нику участника', () => {
  const state = sampleState();
  const today = '2026-10-06';
  const find = (query, filter) => Core.selectAccounts(state, { query: query, filter: filter || 'all' }, today);

  assert.deepEqual(emails(find('BRAVO').groups.active), ['bravo@gmail.com'], 'регистр не важен');
  assert.deepEqual(emails(find('mail.ru').groups.expired), ['charlie@mail.ru']);
  assert.deepEqual(emails(find('spotify').groups.active), ['alpha@gmail.com']);

  let shown = find('alex');
  assert.deepEqual(emails(shown.groups.active), ['alpha@gmail.com']);
  assert.equal(shown.groups.active[0].matched.length, 1, 'совпавший участник отмечен');
  assert.equal(shown.hidden.archived, 1, '@alexa лежит в архиве');

  assert.deepEqual(emails(find('@alex').groups.active), ['alpha@gmail.com'], 'с собачкой');
  assert.deepEqual(emails(find('@max').groups.active), ['alpha@gmail.com'], 'ник записан без собачки, ищем с ней');
  assert.deepEqual(emails(find('  john  ').groups.active), ['bravo@gmail.com'], 'пробелы вокруг не мешают');

  shown = find('kate', 'active');
  assert.equal(shown.count, 0);
  assert.equal(shown.hidden.other, 1, 'совпадение есть, но не в этом фильтре');

  shown = find('gmail');
  assert.equal(shown.count, 3);
  assert.equal(shown.hidden.archived, 1);

  assert.equal(find('никого-такого').count, 0);
  assert.deepEqual(emails(find('alexa', 'archived').groups.archived), ['echo@gmail.com']);
});

test('сортировка: по дате окончания, по свободным местам, по дате добавления', () => {
  const state = sampleState();
  const today = '2026-10-06';
  const order = (sort) => emails(Core.selectAccounts(state, { filter: 'active', sort: sort }, today).groups.active);
  assert.deepEqual(order('end'), ['bravo@gmail.com', 'delta@gmail.com', 'alpha@gmail.com']);
  assert.deepEqual(order('free'), ['bravo@gmail.com', 'alpha@gmail.com', 'delta@gmail.com']);
  assert.deepEqual(order('added'), ['delta@gmail.com', 'bravo@gmail.com', 'alpha@gmail.com']);
  assert.deepEqual(order('чепуха'), order('end'));

  const expired = stateWith([['x@example.com', '2026-06-01'], ['y@example.com', '2026-08-01'], ['z@example.com', '2026-07-01']]);
  assert.deepEqual(
    emails(Core.selectAccounts(expired, { filter: 'expired', sort: 'end' }, today).groups.expired),
    ['y@example.com', 'z@example.com', 'x@example.com'],
    'у истёкших сверху те, что закончились позже'
  );
});

/* ───────────────────────── Чтение сохранённых данных ───────────────────────── */

test('пустое или испорченное хранилище не роняет раздел', () => {
  const empty = { version: 1, accounts: [], prefs: { warnDays: 7, notify: true, sort: 'end' } };
  for (const raw of [undefined, null, 'строка', 42, [], {}, { accounts: 'нет' }, { accounts: [null, 5, 'x', {}] }]) {
    assert.deepEqual(Core.normalizeState(raw), empty);
  }
});

test('сохранённые данные читаются без потерь и одинаково каждый раз', () => {
  const state = sampleState();
  Core.renewAccount(state, state.accounts[0].id, { date: '2026-10-06' }, NOW);
  const saved = JSON.parse(JSON.stringify(state));
  const once = Core.normalizeState(saved);
  assert.deepEqual(once, state);
  assert.deepEqual(Core.normalizeState(JSON.parse(JSON.stringify(once))), once);
});

test('неполные записи чинятся, лишнее отбрасывается', () => {
  const state = Core.normalizeState({
    prefs: { warnDays: 999, notify: 'да', sort: 'как-нибудь' },
    accounts: [
      { id: 'one', email: 'a@example.com', password: 'p', subscriptionStartDate: '2026-10-06' },
      { id: 'one', email: 'b@example.com', password: 'p', subscriptionEndDate: '2026-11-06' },
      { email: 'c@example.com', subscriptionStartDate: '2026-11-10', subscriptionEndDate: '2026-11-06', archived: 'yes' },
      { email: 'd@example.com' },
      {
        id: 'many',
        email: 'e@example.com',
        subscriptionStartDate: '2026-10-06',
        subscriptionEndDate: '2026-11-06',
        members: [
          { id: 'm', nickname: '@a', endDate: '2026-11-01' },
          { id: 'm', nickname: '@b', endDate: '2026-11-01' },
          { nickname: '', endDate: '2026-11-01' },
          { nickname: '@c', endDate: 'чепуха' },
          { nickname: '@d', endDate: '2026-11-01', startDate: '2026-12-01' },
          { nickname: '@e', endDate: '2026-11-01' },
          { nickname: '@f', endDate: '2026-11-01' },
          { nickname: '@g', endDate: '2026-11-01' },
        ],
        renewalHistory: [{ type: 'взлом', date: '2026-10-06', endDate: '2026-11-06' }, null],
      },
    ],
  });

  assert.deepEqual(state.prefs, { warnDays: 7, notify: true, sort: 'end' });
  assert.equal(state.accounts.length, 4, 'запись без единой даты отброшена');
  assert.equal(new Set(state.accounts.map((account) => account.id)).size, 4, 'повторный идентификатор заменён');
  assert.equal(state.accounts[0].subscriptionEndDate, '2026-11-06', 'окончание досчитано от покупки');
  assert.equal(state.accounts[1].subscriptionStartDate, '2026-10-06', 'покупка досчитана от окончания');
  assert.equal(state.accounts[2].subscriptionStartDate, '2026-11-06', 'покупка позже окончания поправлена');
  assert.equal(state.accounts[2].archived, false);
  assert.equal(state.accounts[2].password, '');

  const many = state.accounts[3];
  assert.equal(many.members.length, 5, 'не больше пяти участников');
  assert.deepEqual(many.members.map((member) => member.nickname), ['@a', '@b', '@d', '@e', '@f']);
  assert.equal(new Set(many.members.map((member) => member.id)).size, 5);
  assert.equal(many.members[2].startDate, '', 'начало позже окончания убрано');
  assert.equal(many.renewalHistory.length, 1, 'вместо негодной истории — запись о покупке');
  assert.equal(many.renewalHistory[0].type, 'purchase');

  assert.deepEqual(Core.normalizeState(JSON.parse(JSON.stringify(state))), state, 'повторное чтение ничего не меняет');
});

test('настройки раздела: порог, уведомления, сортировка', () => {
  assert.deepEqual(Core.normalizePrefs({ warnDays: 3, notify: false, sort: 'free' }), { warnDays: 3, notify: false, sort: 'free' });
  assert.deepEqual(Core.normalizePrefs({ warnDays: 0 }), { warnDays: 0, notify: true, sort: 'end' });
  assert.equal(Core.normalizePrefs({ warnDays: -1 }).warnDays, 7);
  assert.equal(Core.normalizePrefs({ warnDays: 2.5 }).warnDays, 7);
  assert.equal(Core.normalizePrefs({ warnDays: '5' }).warnDays, 7);
  assert.equal(Core.normalizePrefs({ warnDays: 61 }).warnDays, 7);
  assert.deepEqual(Core.normalizePrefs(null), { warnDays: 7, notify: true, sort: 'end' });
});

/* ───────────────────────── Экспорт и импорт ───────────────────────── */

test('экспорт содержит все данные и восстанавливается без потерь', () => {
  const state = sampleState();
  state.prefs = { warnDays: 5, notify: false, sort: 'free' };
  Core.renewAccount(state, state.accounts[0].id, { date: '2026-10-06' }, NOW);

  const file = JSON.stringify(Core.exportData(state, NOW));
  const data = JSON.parse(file);
  assert.equal(data.kind, 'invites');
  assert.equal(data.version, 1);
  assert.equal(data.accounts.length, 5);
  assert.equal(data.accounts[0].password, 'pw-0');
  assert.equal(data.accounts[0].members.length, 2);
  assert.equal(data.accounts[0].renewalHistory.length, 2);

  const parsed = Core.parseImport(file);
  assert.equal(parsed.ok, true);
  assert.equal(parsed.rejected, 0);

  const restored = Core.emptyState();
  assert.deepEqual(Core.applyImport(restored, parsed, {}), { added: 5, updated: 0, skipped: 0 });
  assert.deepEqual(restored, state, 'после переустановки всё на месте, включая настройки');
});

test('импорт не трогает существующие аккаунты, пока об этом не попросили', () => {
  const state = sampleState();
  const file = JSON.stringify(Core.exportData(state, NOW));

  // После экспорта данные в расширении изменились: один аккаунт продлили, один добавили.
  Core.renewAccount(state, state.accounts[0].id, { date: '2026-10-06' }, NOW);
  Core.createAccount(state, { email: 'new@example.com', password: 'p', subscriptionStartDate: '2026-10-06' }, NOW);
  Core.deleteAccount(state, state.accounts[1].id);
  const parsed = Core.parseImport(file);

  assert.deepEqual(Core.countImport(state, parsed.accounts), { fresh: 1, same: 4 });

  const careful = JSON.parse(JSON.stringify(state));
  assert.deepEqual(Core.applyImport(careful, parsed, { replace: false }), { added: 1, updated: 0, skipped: 4 });
  assert.equal(careful.accounts.length, 6);
  assert.equal(careful.accounts[0].subscriptionEndDate, '2026-12-01', 'продление не затёрто');
  assert.ok(careful.accounts.some((account) => account.email === 'new@example.com'));
  assert.ok(careful.accounts.some((account) => account.email === 'bravo@gmail.com'), 'удалённый аккаунт вернулся из файла');

  const replacing = JSON.parse(JSON.stringify(state));
  assert.deepEqual(Core.applyImport(replacing, parsed, { replace: true }), { added: 1, updated: 4, skipped: 0 });
  assert.equal(replacing.accounts.length, 6, 'даже при замене ничего не удаляется');
  assert.equal(replacing.accounts[0].subscriptionEndDate, '2026-11-01', 'совпавший аккаунт взят из файла');
  assert.ok(replacing.accounts.some((account) => account.email === 'new@example.com'));
  assert.deepEqual(replacing.prefs, state.prefs, 'настройки непустого раздела не меняются');
});

test('импорт проверяет структуру файла', () => {
  const code = (content) => Core.parseImport(content).code;
  assert.equal(code('не json'), 'not-json');
  assert.equal(code(''), 'not-json');
  assert.equal(code('[]'), 'wrong-format');
  assert.equal(code('null'), 'wrong-format');
  assert.equal(code('{}'), 'wrong-format');
  assert.equal(code(JSON.stringify({ kind: 'orders', version: 1, accounts: [] })), 'wrong-format');
  assert.equal(code(JSON.stringify({ kind: 'invites', version: 1, accounts: {} })), 'wrong-format');
  assert.equal(code(JSON.stringify({ kind: 'invites', accounts: [] })), 'wrong-format');
  assert.equal(code(JSON.stringify({ kind: 'invites', version: 2, accounts: [{}] })), 'newer-version');
  assert.equal(code(JSON.stringify({ kind: 'invites', version: 1, accounts: [] })), 'empty');
  assert.equal(code(JSON.stringify({ kind: 'invites', version: 1, accounts: [{ email: 'a@example.com' }, null, 7] })), 'no-valid');
});

test('импорт берёт годные записи и считает негодные', () => {
  const good = { id: 'keep', email: 'a@example.com', password: 'p', subscriptionStartDate: '2026-10-06', subscriptionEndDate: '2026-11-06' };
  const parsed = Core.parseImport(
    JSON.stringify({
      kind: 'invites',
      version: 1,
      prefs: { warnDays: 3 },
      accounts: [
        good,
        Object.assign({}, good, { email: 'двойник@example.com' }), // тот же id второй раз
        Object.assign({}, good, { id: 'no-email', email: '' }),
        Object.assign({}, good, { id: 'bad-date', subscriptionEndDate: '2026-02-30' }),
        Object.assign({}, good, { id: 'reversed', subscriptionStartDate: '2026-12-01' }),
        Object.assign({}, good, { id: undefined, email: 'noid@example.com' }),
        Object.assign({}, good, { id: 'six', email: 'six@example.com', members: Array.from({ length: 8 }, (u, i) => ({ nickname: 'n' + i, endDate: '2026-11-01' })) }),
      ],
    })
  );
  assert.equal(parsed.ok, true);
  assert.equal(parsed.rejected, 4);
  assert.deepEqual(parsed.accounts.map((account) => account.email), ['a@example.com', 'noid@example.com', 'six@example.com']);
  assert.equal(parsed.accounts[0].id, 'keep');
  assert.ok(parsed.accounts[1].id && parsed.accounts[1].id !== 'keep', 'записи без идентификатора он выдан');
  assert.equal(parsed.accounts[2].members.length, 5, 'шестого участника нельзя и через импорт');
  assert.equal(parsed.prefs.warnDays, 3);
});

/* ───────────────────────── Уведомления ───────────────────────── */

test('уведомления: каждый этап одного срока — один раз', () => {
  const state = stateWith([['example@gmail.com', '2026-10-01']]); // до 01.11.2026
  let marks = {};
  const names = [];
  const run = (day, mode) => {
    const result = Core.dueNotifications(state, day, marks, mode || 'show');
    marks = result.marks;
    for (const item of result.due) names.push(day + ' ' + item.daysLeft);
    return result.due;
  };

  assert.equal(run('2026-10-06').length, 0, 'срок встречен впервые — запоминаем молча');
  assert.equal(run('2026-10-20').length, 0, 'до конца ещё далеко');
  assert.equal(run('2026-10-25').length, 1, 'осталось 7 дней');
  assert.equal(run('2026-10-25').length, 0, 'повторная проверка в тот же день молчит');
  assert.equal(run('2026-10-28').length, 0, 'между этапами молчит');
  assert.equal(run('2026-10-31').length, 1, 'остался день');
  assert.equal(run('2026-11-01').length, 0, 'последний день — тот же этап');
  assert.equal(run('2026-11-02').length, 1, 'истекла');
  assert.equal(run('2026-11-03').length, 0);
  assert.equal(run('2026-12-03').length, 0, 'про истёкшую больше не напоминает');
  assert.deepEqual(names, ['2026-10-25 7', '2026-10-31 1', '2026-11-02 -1']);
});

test('уведомления: браузер был закрыт — приходит только последний этап', () => {
  const state = stateWith([['example@gmail.com', '2026-10-01']]);
  const first = Core.dueNotifications(state, '2026-10-06', {}, 'show');
  const later = Core.dueNotifications(state, '2026-11-05', first.marks, 'show');
  assert.equal(later.due.length, 1);
  assert.equal(later.due[0].stage, 3);
});

test('уведомления: только что вписанный аккаунт с близким сроком не шумит', () => {
  const state = stateWith([['soon@example.com', '2026-09-10'], ['old@example.com', '2026-07-01']]);
  const first = Core.dueNotifications(state, '2026-10-06', {}, 'show');
  assert.equal(first.due.length, 0, 'о том, что человек сам только что ввёл, не сообщаем');
  const next = Core.dueNotifications(state, '2026-10-09', first.marks, 'show');
  assert.deepEqual(next.due.map((item) => item.name), ['soon@example.com'], 'дальше этапы идут как обычно');
  assert.equal(next.due[0].daysLeft, 1);
});

test('уведомления: после продления отсчёт начинается заново', () => {
  const state = stateWith([['example@gmail.com', '2026-10-01']]);
  const account = state.accounts[0];
  let result = Core.dueNotifications(state, '2026-10-06', {}, 'show');
  result = Core.dueNotifications(state, '2026-10-26', result.marks, 'show');
  assert.equal(result.due.length, 1);

  Core.renewAccount(state, account.id, { date: '2026-10-26' }, NOW); // теперь до 01.12.2026
  result = Core.dueNotifications(state, '2026-10-26', result.marks, 'show');
  assert.equal(result.due.length, 0);
  result = Core.dueNotifications(state, '2026-11-24', result.marks, 'show');
  assert.equal(result.due.length, 1, 'новый срок — новое напоминание');
  assert.equal(result.due[0].daysLeft, 7);
});

test('уведомления: архив молчит, выключенные запоминаются молча, ночью откладываются', () => {
  const state = stateWith([['a@example.com', '2026-10-01'], ['b@example.com', '2026-10-01']]);
  const base = Core.dueNotifications(state, '2026-10-06', {}, 'show').marks;

  Core.setArchived(state, state.accounts[1].id, true);
  const archived = Core.dueNotifications(state, '2026-10-26', base, 'show');
  assert.deepEqual(archived.due.map((item) => item.name), ['a@example.com']);
  Core.setArchived(state, state.accounts[1].id, false);
  assert.equal(Core.dueNotifications(state, '2026-10-26', archived.marks, 'show').due.length, 0, 'после возврата из архива старое не всплывает');

  const muted = Core.dueNotifications(state, '2026-10-26', base, 'mute');
  assert.equal(muted.due.length, 0);
  assert.equal(Core.dueNotifications(state, '2026-10-26', muted.marks, 'show').due.length, 0, 'после включения старое не всплывает');

  const deferred = Core.dueNotifications(state, '2026-10-26', base, 'defer');
  assert.equal(deferred.due.length, 0);
  assert.equal(Core.dueNotifications(state, '2026-10-26', deferred.marks, 'show').due.length, 2, 'отложенное приходит позже');
});

test('уведомления: испорченные отметки не мешают', () => {
  const state = stateWith([['a@example.com', '2026-10-01']]);
  for (const marks of [null, undefined, 'строка', 5, { [state.accounts[0].id]: null }, { [state.accounts[0].id]: { end: 1 } }]) {
    const result = Core.dueNotifications(state, '2026-10-26', marks, 'show');
    assert.equal(result.due.length, 0);
    assert.deepEqual(result.marks[state.accounts[0].id], { end: '2026-11-01', stage: 1 });
  }
});

test('текст уведомлений', () => {
  const item = (daysLeft, name) => ({ name: name || 'example@gmail.com', daysLeft: daysLeft });
  assert.deepEqual(Core.notificationContent([item(7)]), {
    title: 'Подписка скоро закончится',
    message: 'Подписка example@gmail.com закончится через 7 дней.',
  });
  assert.equal(Core.notificationContent([item(2)]).message, 'Подписка example@gmail.com закончится через 2 дня.');
  assert.equal(Core.notificationContent([item(21)]).message, 'Подписка example@gmail.com закончится через 21 день.');
  assert.equal(Core.notificationContent([item(1)]).message, 'Подписка example@gmail.com закончится завтра.');
  assert.equal(Core.notificationContent([item(0)]).message, 'Подписка example@gmail.com закончится сегодня.');
  assert.deepEqual(Core.notificationContent([item(-1)]), {
    title: 'Подписка истекла',
    message: 'Подписка example@gmail.com истекла.',
  });

  const many = Core.notificationContent([item(-1, 'a@x.io'), item(1, 'b@x.io'), item(5, 'c@x.io'), item(6, 'd@x.io'), item(7, 'e@x.io'), item(7, 'f@x.io')]);
  assert.equal(many.title, 'Подписки требуют внимания: 6');
  assert.equal(many.message, ['a@x.io — истекла', 'b@x.io — закончится завтра', 'c@x.io — закончится через 5 дней', 'd@x.io — закончится через 6 дней', 'и ещё 2'].join('\n'));
  assert.ok(!many.message.includes('pw-'), 'паролей в уведомлениях нет');
});

test('склонение', () => {
  const days = (n) => Core.plural(n, 'день', 'дня', 'дней');
  assert.deepEqual([1, 2, 4, 5, 11, 12, 21, 22, 25, 101, 111].map(days), ['день', 'дня', 'дня', 'дней', 'дней', 'дней', 'день', 'дня', 'дней', 'день', 'дней']);
});
