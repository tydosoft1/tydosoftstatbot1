# tydosoftstatbot
браузерное расширение для учета продаж funpay магазина
